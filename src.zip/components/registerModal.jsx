import { AnimatePresence, motion } from "framer-motion";
import { useRouter } from "next/router";
import { useEffect, useState } from "react";
import { AiOutlineShareAlt } from "react-icons/ai";
import {
  DeleteActionCookie,
  DeleteAuthCookie,
  SaveAuthCookie,
} from "../utils/cookies";
import { fethcStats } from "../utils/utils";

export const RegisterModal = ({ open, setIsOpen, loggedIn }) => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState({
    type: "",
    message: "",
  });
  const router = useRouter();
  return loggedIn == false ? (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ y: 0, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 0, opacity: 0 }}
          transition={{ bounce: 0 }}
          className="settings flex h-full justify-center items-center inset-0 fixed bg-black/20"
          onClick={() => {
            setIsOpen(false);
          }}
        >
          <motion.form
            initial={{ y: 40, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 40, opacity: 0 }}
            transition={{ bounce: 0 }}
            className="mx-auto max-w-md bg-white dark:bg-gray-800  shadow-lg w-full rounded-lg overflow-clip flex flex-col"
            onClick={(e) => {
              e.stopPropagation();
            }}
            onSubmit={async (e) => {
              e.preventDefault();
              const res = await fetch("/api/register", {
                method: "POST",
                body: JSON.stringify({ username, password, email }),
              });
              const json = await res.json();
              if (res.status == 200) {
                DeleteActionCookie();
                setMessage({
                  type: "success",
                  message: "Account Created! You can now login!",
                });
              } else if (res.status == 400) {
                setMessage({
                  type: "error",
                  message: json.error,
                });
              }
            }}
          >
            <div className="bg-gray-100 dark:bg-gray-700 dark:border-gray-600 py-4 text-xl font-bold text-center border-b text-black/80 dark:text-white">
              <h1 className="">REGISTER</h1>
            </div>

            <div className="p-4 ">
              <span>Username</span>
              <input
                required
                type="text"
                value={username}
                onChange={(e) => {
                  setUsername(e.target.value);
                }}
                className=" required:border-red-500 invalid:border-red-500 border rounded w-full p-2 mb-4 mt-1 bg-gray-200 dark:bg-gray-600 dark:border-gray-500 dark:placeholder:text-gray-300 placeholder:text-gray-500 placeholder:font-medium"
                placeholder="username"
              />

              <span>Email</span>
              <input
                required
                value={email}
                onChange={(e) => {
                  setEmail(e.target.value);
                }}
                type="email"
                className="required:border-red-500 invalid:border-red-500 border mt-1 mb-4 rounded w-full p-2 bg-gray-200 dark:bg-gray-600 dark:border-gray-500 dark:placeholder:text-gray-300 placeholder:text-gray-500 placeholder:font-medium"
                placeholder="email"
              />

              <span>Password</span>
              <input
                required
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                }}
                type="password"
                className=" required:border-red-500 invalid:border-red-500 border mt-1 rounded w-full p-2 bg-gray-200 dark:bg-gray-600 dark:border-gray-500 dark:placeholder:text-gray-300 placeholder:text-gray-500 placeholder:font-medium"
                placeholder="password"
              />

              {message.type.length > 0 && (
                <div
                  className={`mt-4 py-2 px-4 rounded-md  text-white font-medium w-full ${
                    message.type == "success" ? "bg-green-600" : "bg-red-600"
                  }`}
                >
                  {message.message}
                </div>
              )}
            </div>

            <div className="flex justify-between gap-4 p-4 bg-gray-100 dark:bg-gray-700 dark:border-gray-600 border-t ">
              <button
                type="submit"
                className="flex-1 bg-emerald-700 hover:bg-emerald-600 py-2 rounded-md text-white font-medium inline-flex gap-2 items-center justify-center"
              >
                Register
              </button>
            </div>
          </motion.form>
        </motion.div>
      )}
    </AnimatePresence>
  ) : (
    <></>
  );
};
