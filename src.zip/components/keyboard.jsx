import { useState } from "react";
import { BsArrowReturnLeft, BsEraserFill } from "react-icons/bs";
import { PaymentModal } from "./payment";

const keyboard_row_1 = ["q", "w", "e", "r", "t", "y", "u", "i", "o", "p"];
const keyboard_row_2 = ["a", "s", "d", "f", "g", "h", "j", "k", "l"];
const keyboard_row_3 = ["z", "x", "c", "v", "b", "n", "m"];

export const Keyboard = ({
  board,
  insert_key,
  delete_key,
  submit_word,
  user,
  showLogin,
  wrongLetters,
  correctLetters,
  missLetters,
  currentWord,
  size,
  loggedIn,
  setRegisterOpen,
  setLoginOpen,
}) => {
  const hintKeyboardClass = (key) => {
    if (correctLetters.includes(key))
      return "!bg-green-600 !border-green-600 text-white";
    if (missLetters.includes(key))
      return "!bg-amber-500 !border-amber-500 text-white";
    if (wrongLetters.includes(key))
      return "!bg-gray-800 !border-gray-500 text-white opacity-30";
  };

  const [showPayment, setShowPayment] = useState(false);

  return board.current != null ? (
    <>
      <div className="keyboard p-4 space-y-1 w-screen md:max-w-xl mx-auto">
        <div className="relative mb-2">
          <div className="flex gap-2 w-full mb-1 ">
            <button
              onClick={() => {
                if (user === null || (user.paid !== 1 && user.is_admin !== 1)) {
                  setShowPayment(true);
                } else {
                  board.current.changeSize(size == 5 ? 6 : 5);
                }
              }}
              className=" flex-1 bg-emerald-600 py-2 rounded-md text-white font-medium transition-all hover:shadow-emerald-700 hover:shadow-[0_4px_0] hover:-translate-y-1"
            >
              {size == 5 ? "6 letters mode" : "5 letters mode"}
            </button>
            <button
              onClick={() => {
                if (user === null || (user.paid !== 1 && user.is_admin !== 1)) {
                  setShowPayment(true);
                } else {
                  board.current.changeSize(size == 7 ? 6 : 7);
                }
              }}
              className="flex-1 bg-emerald-600 py-2 rounded-md text-white font-medium transition-all hover:shadow-emerald-700 hover:shadow-[0_4px_0] hover:-translate-y-1"
            >
              {size == 7 ? "6 letters mode" : "7 letters mode"}
            </button>
          </div>
        </div>
        <div className="flex gap-1">
          {keyboard_row_1.map((key) => (
            <button
              className={`kbd ${hintKeyboardClass(key)}`}
              onClick={() => {
                insert_key(key);
              }}
              key={key}
            >
              {key}
            </button>
          ))}
        </div>
        <div className="flex gap-1">
          {keyboard_row_2.map((key) => (
            <button
              className={`kbd ${hintKeyboardClass(key)}`}
              onClick={() => {
                insert_key(key);
              }}
              key={key}
            >
              {key}
            </button>
          ))}
        </div>
        <div className="flex gap-1">
          <button
            disabled={currentWord.length < board.current.size()}
            onClick={() => {
              submit_word();
            }}
            className="disabled:opacity-50 disabled:bg-emerald-700 bg-emerald-700 text-white kbd hover:!shadow-emerald-900"
          >
            <BsArrowReturnLeft />
          </button>
          {keyboard_row_3.map((key) => (
            <button
              className={`kbd ${hintKeyboardClass(key)}`}
              onClick={() => {
                insert_key(key);
              }}
              key={key}
            >
              {key}
            </button>
          ))}

          <button
            disabled={currentWord.length == 0}
            onClick={() => {
              delete_key();
            }}
            className="disabled:opacity-50 disabled:bg-emerald-700 bg-emerald-700 text-white kbd hover:!shadow-emerald-900"
          >
            <BsEraserFill />
          </button>
        </div>
      </div>
      <PaymentModal
        loggedIn={loggedIn}
        setRegisterOpen={setRegisterOpen}
        open={showPayment}
        setIsOpen={setShowPayment}
        setLoginOpen={setLoginOpen}
      />
    </>
  ) : (
    <></>
  );
};
