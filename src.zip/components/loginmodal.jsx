import { AnimatePresence, motion } from "framer-motion";
import { useRouter } from "next/router";
import { useEffect, useState } from "react";
import { AiOutlineShareAlt } from "react-icons/ai";
import { DeleteAuthCookie, SaveAuthCookie } from "../utils/cookies";
import { fethcStats } from "../utils/utils";

export const LoginModal = ({ open, setIsOpen, loggedIn }) => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState({
    type: "",
    message: "",
  });
  const router = useRouter();
  return loggedIn == false ? (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ y: 0, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 0, opacity: 0 }}
          transition={{ bounce: 0 }}
          className="settings flex h-full justify-center items-center inset-0 fixed bg-black/20"
          onClick={() => {
            setIsOpen(false);
          }}
        >
          <motion.div
            initial={{ y: 40, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 40, opacity: 0 }}
            transition={{ bounce: 0 }}
            className="mx-auto max-w-md bg-white dark:bg-gray-800  shadow-lg w-full rounded-lg overflow-clip flex flex-col"
            onClick={(e) => {
              e.stopPropagation();
            }}
          >
            <div className="bg-gray-100 dark:bg-gray-700 dark:border-gray-600 py-4 text-xl font-bold text-center border-b text-black/80 dark:text-white">
              <h1 className="">LOGIN</h1>
            </div>

            <div className="p-4 ">
              <span>Username</span>
              <input
                required
                type="text"
                value={username}
                onChange={(e) => {
                  setUsername(e.target.value);
                }}
                className="border rounded w-full p-2 mb-4 mt-1 bg-gray-200 dark:bg-gray-600 dark:border-gray-500 dark:placeholder:text-gray-300 placeholder:text-gray-500 placeholder:font-medium"
                placeholder="username"
              />
              <span>Password</span>
              <input
                required
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                }}
                type="password"
                className="border mt-1 rounded w-full p-2 bg-gray-200 dark:bg-gray-600 dark:border-gray-500 dark:placeholder:text-gray-300 placeholder:text-gray-500 placeholder:font-medium"
                placeholder="password"
              />

              {message.type.length > 0 && (
                <div
                  className={`mt-4 py-2 px-4 rounded-md  text-white font-medium w-full ${
                    message.type == "success" ? "bg-green-600" : "bg-red-600"
                  }`}
                >
                  {message.message}
                </div>
              )}
            </div>

            <div className="flex justify-between gap-4 p-4 bg-gray-100 dark:bg-gray-700 dark:border-gray-600 border-t ">
              <button
                onClick={async () => {
                  const res = await fetch("/api/login", {
                    method: "POST",
                    body: JSON.stringify({ username, password }),
                  });
                  const json = await res.json();
                  if (res.status == 200) {
                    SaveAuthCookie(json.username);
                    router.reload();
                  } else if (res.status == 400) {
                    DeleteAuthCookie(json.user);
                    setMessage({
                      type: "error",
                      message: json.error,
                    });
                  }
                }}
                className="flex-1 bg-emerald-700 hover:bg-emerald-600 py-2 rounded-md text-white font-medium inline-flex gap-2 items-center justify-center"
              >
                Login
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  ) : (
    <></>
  );
};
