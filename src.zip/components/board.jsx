import randomInteger from "random-int";
import React, { useEffect, useImperativeHandle, useState } from "react";
import useDynamicRefs from "use-dynamic-refs";
import { Square } from "../components/square";
import { ResultScreen } from "./results";

export const Board = React.forwardRef((props, ref) => {
  const { allWords, showResults, stats } = props;
  const [answer, setAnswer] = useState("");
  const [words, setWords] = useState({ answers: [], guesses: [] });
  const [size, setSize] = useState(5);
  const [currentRow, setCurrentRow] = useState(0);
  const [rows, setRows] = useState(["", "", "", "", "", ""]);
  const [hints, setHints] = useState(["", "", "", "", "", ""]);
  const [paused, setPaused] = useState(false);
  const [revealing, setRevealing] = useState(false);
  const [gameEnded, setGameEnded] = useState(false);
  const [gameWon, setGameWon] = useState(false);
  const [getRef, setRef] = useDynamicRefs();

  const [solution, setSolution] = useState([]);
  const [lettersFound, setLettersFound] = useState([]);

  const wingame = () => {
    setGameWon(true);
    setGameEnded(true);
    props.updateScore(true);
  };

  const checkWord = () => {
    const fixedLetters = [];
    const word = rows[currentRow];
    let answerArray = answer.split("");

    if (props.hardMode) {
      for (let i = 0; i < size; i++) {
        if (solution[i] != "" && solution[i] != word[i]) {
          props.setError(
            `The letter ${String(
              solution[i]
            ).toUpperCase()} must be used at position ${i + 1}`
          );
          return;
        }
      }

      for (let i = 0; i < lettersFound.length; i++) {
        if (lettersFound[i] != "" && !word.includes(lettersFound[i])) {
          props.setError(`The letter ${lettersFound[i]} must be used`);
          return;
        }
      }
    }

    props.setCurrentWord("");

    if (words.guesses.includes(word) || words.answers.includes(word)) {
      const newHint = ["b", "b", "b", "b", "b", "b", "b", "b"];
      const wrong = [];
      const correct = [];
      const misplaced = [];

      const found = [];

      for (let i = 0; i < word.length; i++) {
        wrong.push(word[i]);
      }

      // We look for matches
      for (let i = word.length - 1; i >= 0; i--) {
        if (word[i] === answer[i]) {
          newHint[i] = "g";
          answerArray.splice(i, 1);
          fixedLetters[i] = answer[i];
          wrong = wrong.filter((l) => l !== word[i]);
          correct.push(word[i]);
          found.push(word[i]);
        }
      }

      // We look for misplaced letters
      for (let i = 0; i < word.length; i++) {
        if (answerArray.includes(word[i]) && newHint[i] !== "g") {
          newHint[i] = "y";
          answerArray.splice(answerArray.indexOf(word[i]), 1);
          wrong = wrong.filter((l) => l !== word[i]);
          misplaced.push(word[i]);
          found.push(word[i]);
        }
      }

      setLettersFound((prev) => [...prev, ...found]);

      setRevealing(true);
      let k = 0;
      const sol = solution;

      for (let i = 0; i < size; i++) {
        if (answer[i] == word[i]) {
          sol[i] = answer[i];
        }
      }

      setSolution([...sol]);

      function myLoop() {
        setTimeout(function () {
          if (k == size) {
            setRevealing(false);
            if (word == answer) {
              wingame();
            } else {
              if (currentRow == 5) {
                setGameEnded(true);
                props.updateScore(false);
              } else {
                setCurrentRow((prev) => prev + 1);
              }
            }
          } else {
            if (newHint[k] == "g") {
              props.setCorrectLetters((prev) => [...prev, word[k]]);
            } else if (newHint[k] == "y") {
              props.setMissLetters((prev) => [...prev, word[k]]);
            } else if (newHint[k] == "b") {
              props.setWrongLetters((prev) => [...prev, word[k]]);
            }

            getRef("row_" + currentRow).current.animateReveal(k);
            setRowHints(hints[currentRow] + newHint[k]);
          }
          k++;
          if (k <= size) {
            myLoop();
          }
        }, 200);
      }
      myLoop();
    } else {
      props.setError(`Couldn't recognize word 😳`);
      clearRow();
      return;
    }
  };

  const initGame = () => {
    props.onGameInit();
    const guesses =
      size == 5
        ? allWords.five.guesses
        : size == 6
        ? allWords.six.guesses
        : allWords.seven.guesses;

    const answers =
      size == 5
        ? allWords.five.answers
        : size == 6
        ? allWords.six.answers
        : allWords.seven.answers;

    setWords({ answers, guesses });
    props.setCorrectLetters([]);
    props.setWrongLetters([]);
    props.setMissLetters([]);
    props.setCurrentWord("");
    const r = randomInteger(0, answers.length);
    setAnswer(answers[r]);

    for (let i = 0; i < 6; i++) {
      setRef("row_" + i);
    }

    const sol = [];
    for (let i = 0; i < size; i++) {
      sol.push("");
    }

    setLettersFound([]);
    setSolution([...sol]);
    setRows(["", "", "", "", "", ""]);
    setHints(["", "", "", "", "", ""]);
    setCurrentRow(0);
    setGameEnded(false);
    setGameWon(false);
    setRevealing(false);
    setPaused(false);
  };

  useEffect(() => {
    props.setGlobalSize(size);
    initGame();
  }, [size]);

  useEffect(() => {
    if (gameEnded) {
      props.onGameEnd();
    }
  }, [gameEnded]);

  const clearRow = () => {
    const _rows = rows;
    _rows[currentRow] = "";
    setRows([..._rows]);
  };
  const setRowHints = (h) => {
    const _hints = hints;
    _hints[currentRow] = h;
    setHints([..._hints]);
  };
  const clear = () => {
    initGame();
  };
  useImperativeHandle(ref, () => ({
    clear: () => {
      clear();
    },
    currentWord: () => rows[currentRow],
    answer: () => answer,
    size: () => size,
    gameEnded: () => gameEnded,
    pause: () => {
      setPaused(true);
    },
    unpause: () => {
      setPaused(false);
    },
    insertKey: (k) => {
      if (gameEnded || paused || revealing) return;
      const _rows = rows;
      if (_rows[currentRow].length == size) return;

      getRef("row_" + currentRow).current.animateType(_rows[currentRow].length);

      _rows[currentRow] += k;

      props.setCurrentWord(_rows[currentRow]);

      setRows([..._rows]);
    },
    deleteKey: () => {
      if (gameEnded || paused || revealing) return;
      const _rows = rows;
      if (_rows[currentRow].length == 0) return;
      _rows[currentRow] = _rows[currentRow].slice(0, -1);
      getRef("row_" + currentRow).current.animateType(_rows[currentRow].length);

      props.setCurrentWord(_rows[currentRow]);
      setRows([..._rows]);
    },
    submit: async () => {
      if (gameEnded || paused || revealing) return;
      if (rows[currentRow].length < size) {
        props.setError(`Word must be ${size} letters long 😬`);
      } else {
        checkWord();
      }
    },
    changeSize: async (size) => {
      setSize(size);
      clear();
    },
  }));

  return (
    <>
      {rows.length == 6 &&
        rows.map((_, i) => (
          <Row
            ref={getRef("row_" + i)}
            order={i}
            row={rows[i]}
            size={size}
            hints={hints[i]}
            key={`row_${i}`}
          />
        ))}
      <ResultScreen
        gameEnded={gameEnded}
        newGame={clear}
        gameWon={gameWon}
        tries={currentRow}
        size={size}
        answer={answer}
        stats={stats}
        hints={hints}
        user={props.user}
      />
    </>
  );
});

const Row = React.forwardRef(({ row, size, hints, order }, ref) => {
  const [getRef, setRef] = useDynamicRefs();
  useEffect(() => {}, [row]);
  useImperativeHandle(ref, () => ({
    animateType: (i) => {
      getRef(`row_${order}_${i}`).current.typeAnimation();
    },
    animateReveal: (i) => {
      getRef(`row_${order}_${i}`).current.revealAnimation();
    },
  }));

  const cells = [];
  for (let i = 0; i < size; i++) {
    setRef(`row_${order}_${i}`);
    cells.push(i);
  }
  return (
    <div
      className={`grid gap-2 h-fit ${
        size == 5 ? "grid-cols-5" : size == 6 ? "grid-cols-6" : "grid-cols-7"
      }`}
    >
      {cells.map((_, i) => {
        return (
          <Square
            key={`case_${i}`}
            letter={row[i]}
            ref={getRef(`row_${order}_${i}`)}
            hint={hints[i]}
          />
        );
      })}
    </div>
  );
});
