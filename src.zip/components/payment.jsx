import { AnimatePresence, motion } from "framer-motion";
import { useRouter } from "next/router";
import { useEffect } from "react";
import {
  DeleteActionCookie,
  GetAuthCookie,
  SaveActionCookie,
} from "../utils/cookies";

export const PaymentModal = ({
  open,
  setIsOpen,
  loggedIn,
  setLoginOpen,
  setRegisterOpen,
}) => {
  useEffect(() => {
    function initPayPalButton() {
      document.getElementById("paypal-button-container").innerHTML = "";
      paypal
        .Buttons({
          style: {
            shape: "rect",
            color: "gold",
            layout: "vertical",
            label: "paypal",
          },

          createOrder: function (data, actions) {
            return actions.order.create({
              purchase_units: [
                {
                  description: "Worldx Unlimited",
                  amount: { currency_code: "USD", value: 5 },
                },
              ],
            });
          },

          onApprove: function (data, actions) {
            return actions.order.capture().then(function (orderData) {
              // Full available details

              // Show a success message within this page, e.g.
              const element = document.getElementById(
                "paypal-button-container"
              );
              element.innerHTML = "";
              element.innerHTML =
                '<h3 className="text-lg font-bold text-green-700">Thank you for your payment!</h3>';

              if (loggedIn) {
                fetch("/api/user", {
                  method: "POST",
                  body: {
                    username: GetAuthCookie(),
                    action: "pay",
                  },
                }).then((_) => {
                  setIsOpen(false);
                  DeleteActionCookie();
                });
              } else {
                SaveActionCookie();
                setIsOpen(false);
                setRegisterOpen(true);
              }
              // Or go to another URL:  actions.redirect('thank_you.html');
            });
          },

          onError: function (err) {},
        })
        .render("#paypal-button-container");
    }
    if (open) initPayPalButton();
  }, [open]);

  const router = useRouter();
  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ y: 0, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 0, opacity: 0 }}
          transition={{ bounce: 0 }}
          className="settings flex h-full justify-center items-center inset-0 fixed bg-black/20"
          onClick={() => {
            setIsOpen(false);
          }}
        >
          <motion.div
            initial={{ y: 40, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 40, opacity: 0 }}
            transition={{ bounce: 0 }}
            className="mx-auto max-w-md bg-white dark:bg-gray-800 shadow-lg w-full rounded-lg overflow-clip flex flex-col"
            onClick={(e) => {
              e.stopPropagation();
            }}
          >
            <div className="bg-gray-100 dark:bg-gray-700 dark:border-b-gray-600 py-4 text-xl font-bold text-center border-b dark:text-white text-black/80">
              <h1 className="">Unlock 6/7 letters mode</h1>
            </div>

            <div className="p-4 space-y-4 ">
              <h2 className="text-center">
                {!loggedIn && "Login OR "}Pay $5 to Unlock Unlimited Play for 6
                and 7 letters modes.
              </h2>
              {!loggedIn && (
                <>
                  <button
                    onClick={() => {
                      setIsOpen(false);
                      setLoginOpen(true);
                    }}
                    className="flex-1 w-full bg-emerald-700 hover:bg-emerald-600 py-2 rounded-md text-white font-medium inline-flex gap-2 items-center justify-center"
                  >
                    Login
                  </button>
                  <hr />
                </>
              )}

              <div className="" id="paypal-button-container"></div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
