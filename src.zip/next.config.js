module.exports = {
  reactStrictMode: true,
  trailingSlash: true
}
