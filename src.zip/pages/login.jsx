import Link from "next/link";
import { useRouter } from "next/router";
import { useEffect, useRef, useState } from "react";
import {
  DeleteAuthCookie,
  GetAuthCookie,
  SaveAuthCookie,
} from "../utils/cookies";

export default function Login() {
  const router = useRouter();
  const [ready, setReady] = useState(false);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const formel = useRef();

  useEffect(() => {
    const user = GetAuthCookie();
    if (user && user != "") {
      router.push("/");
    } else {
      setReady(true);
    }
  }, []);

  return (
    <main
      className="bg-gray-50 h-screen w-screen grid place-items-center"
    >
      {ready && (
        <form
          ref={formel}
          onSubmit={async (e) => {
            e.preventDefault();
            const data = new FormData();
            data.append("username", username);
            data.append("password", password);
            const res = await fetch(
              "http://localhost/wrodlex_development-main/login.php",
              {
                method: "POST",
                body: data,
              }
            );
            const json = await res.json();
            if (json.code == 200) {
              SaveAuthCookie(json.username);
              router.push("/");
            } else if (json.code == 401) {
              DeleteAuthCookie(json.user);
            }
          }}
          className="bg-white p-4 rounded-md shadow-xl w-full max-w-xs text-center flex flex-col gap-4"
        >
          <h1 className="text-xl font-medium my-2">Login</h1>
          <input
            required
            type="text"
            value={username}
            onChange={(e) => {
              setUsername(e.target.value);
            }}
            className="border rounded w-full p-2 bg-gray-200 placeholder:text-gray-500 placeholder:font-medium"
            placeholder="username"
          />
          <input
            required
            value={password}
            onChange={(e) => {
              setPassword(e.target.value);
            }}
            type="password"
            className="border rounded w-full p-2 bg-gray-200 placeholder:text-gray-500 placeholder:font-medium"
            placeholder="password"
          />
          <button
            type="submit"
            className="w-full bg-emerald-600 py-2 rounded-md text-white font-medium hover:bg-emerald-700"
          >
            Login
          </button>
          <Link href={"/register"} passHref>
            <a className="hover:bg-emerald-500/10 py-2 rounded-md text-gray-700 hover:text-emerald-800">
              Register
            </a>
          </Link>
        </form>
      )}
    </main>
  );
}
