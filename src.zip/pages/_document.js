import { Html, Head, Main, NextScript } from 'next/document'

export default function Document() {
  return (
    <Html>
      <Head >
        <script async src="https://www.googletagmanager.com/gtag/js?id=G-XZW2JRT705"></script>
        <script src="https://www.paypal.com/sdk/js?client-id=AT9BORCg0azjKYqHU3OXG1xhEr2J9-sGEntLANB_aemqon8ynoh2s1Hzvqcx&enable-funding=venmo&currency=USD" data-sdk-integration-source="button-factory"></script>
      </Head>
      <body >
        <Main />
        <NextScript />
      </body>
    </Html>
  )
}