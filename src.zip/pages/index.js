import { AnimatePresence, motion } from 'framer-motion';
import knex from 'knex';
import Head from 'next/head';
import { useCallback, useEffect, useRef, useState } from 'react';
import { AiOutlineQuestion, AiOutlineSetting, AiOutlineTrophy } from 'react-icons/ai';
import { Board } from '../components/board';
import { HowToPlay } from '../components/howtoplay';
import { Keyboard } from '../components/keyboard';
import { LoginModal } from '../components/loginmodal';
import { RegisterModal } from '../components/registerModal';
import { SettingsModal } from '../components/settings';
import { UserDropdown } from '../components/userdropdown';
import { UserStats } from '../components/userstats';
import { dbconfig } from '../database/db_connection';
import { fethcStats, saveStats } from '../utils/utils';

function isLetter(str) {
  return str.length === 1 && str.match(/[a-z]/i);
}
export default function Home({ words, loggedIn, isAdmin, user }) {

  const [showLogin, setShowLogin] = useState(false)
  const [showRegister, setShowRegister] = useState(false)
  const [showSettings, setShowSettings] = useState(false)
  const [gameEnded, setGameEnded] = useState(false)
  const [gamepaused, setgamepaused] = useState(false)
  const [error, setError] = useState('')
  const [showResults, setShowResults] = useState(false)
  const [showStats, setShowStats] = useState(false)
  const [showTutorial, setShowTutorial] = useState(true)
  const [stats, setStats] = useState()
  const [hardMode, setHardMode] = useState(false)
  const [wrongLetters, setWrongLetters] = useState([])
  const [missLetters, setMissLetters] = useState([])
  const [correctLetters, setCorrectLetters] = useState([])
  const [currentWord, setCurrentWord] = useState('')
  const [size, setSize] = useState(0)

  const board = useRef(null)

  useEffect(() => {
    async function getStats() {
      setStats(await fethcStats());
    }
    if (user != null)
      getStats()
  }, [])


  async function updateScore(won) {
    if (user == null) return

    const old_stats = await fethcStats()
    const newstreak = won ? (Number.parseInt(old_stats.streak) + 1) : 0;
    const new_stats = {
      games: Number.parseInt(old_stats.games) + 1,
      won: Number.parseInt(old_stats.won) + (won ? 1 : 0),
      streak: newstreak,
      hscore: Math.max(Number.parseInt(old_stats.hscore), newstreak)
    }
    setStats(await saveStats(new_stats))

  }

  useEffect(() => {
    if (error.length > 0) {
      setTimeout(() => {
        setError('')
      }, (1000));
    }
  }, [error])

  const insert_key = (key) => {
    if (showSettings || showResults || showLogin || showStats || showTutorial || showLogin || showRegister) return
    board.current.insertKey(key)
  }

  const delete_key = () => {
    if (showSettings || showResults || gamepaused || showLogin || showStats || showTutorial || showLogin || showRegister) return
    board.current.deleteKey()
  }

  const submit_word = () => {
    if (showSettings || showResults || gamepaused || showLogin || showStats || showTutorial || showLogin || showRegister) return
    board.current.submit()
  }

  const handleKeyDown = useCallback(
    (event) => {
      if (showSettings || showResults || gamepaused || showLogin || showStats || showTutorial || showLogin || showRegister) return
      const letter = event.key.toLowerCase()
      if (isLetter(letter)) {
        insert_key(letter)
      } else if (letter === 'enter') {
        submit_word()
        event.preventDefault()
      } else if (letter === 'backspace') {
        delete_key()
      }
    },
    [insert_key, submit_word, delete_key]
  )

  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown)

    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [handleKeyDown])

  return (
    <div className={`min-h-screen w-full  bg-gray-50 dark:bg-gray-900 transition-colors dark:text-white`}>
      <Head>
        <title>WordleX</title>
        <meta name="description" content="Unlimited WordleX" />
      </Head>

      <main className={` flex flex-col min-h-screen`}>

        <header className='border-b sticky top-0 bg-gray-50 dark:bg-gray-900 dark:border-b-gray-700 w-full grid grid-cols-3 justify-between items-center text-xl py-2 px-8'>
          <button onClick={() => {
            setShowTutorial(true)
          }} className="relative p-1 hover:bg-gray-200 dark:hover:bg-gray-700 rounded mr-auto">
            <AiOutlineQuestion />
          </button>
          <h1 className='text-3xl font-bold tracking-widest ml-auto mr-auto relative '>WORDLE {hardMode && <div className='transition-all bottom-0 inline-block translate-y-full md:translate-y-1/2 left-1/2 md:left-auto -translate-x-1/2 md:-rotate-3 text-sm font-normal absolute w-fit whitespace-nowrap  bg-gray-900 text-white dark:bg-gray-50 dark:text-black p-1 rounded'>Hard Mode</div>} </h1>
          <div className="flex gap-2 justify-end text-opacity-75">
            <UserDropdown loggedin={loggedIn} setStats={setShowStats} isAdmin={isAdmin} setLogin={setShowLogin} setRegister={setShowRegister} />
            <button onClick={() => {
              if (loggedIn) setShowStats(true)
              else setShowLogin(true)
            }} className="relative p-1 hover:bg-gray-200 dark:hover:bg-gray-700  rounded hidden sm:block">
              <AiOutlineTrophy />
            </button>
            <button className="relative p-1 hover:bg-gray-200 dark:hover:bg-gray-700  rounded group" onClick={() => {
              setShowSettings(true)
            }}>
              <AiOutlineSetting className='group-hover:rotate-90 transition-transform duration-300' />
            </button>
          </div>
        </header>

        <div className="game flex justify-center items-center flex-1  flex-col gap-2 w-fit py-10 max-w-lg mx-auto">
          <Board ref={board} allWords={words} stats={stats}
            onGameEnd={() => { setGameEnded(true) }}
            onGameInit={() => { setGameEnded(false) }}
            setError={setError}
            setWrongLetters={setWrongLetters}
            setCorrectLetters={setCorrectLetters}
            setMissLetters={setMissLetters}
            updateScore={updateScore}
            hardMode={hardMode}
            setCurrentWord={setCurrentWord}
            user={user}
            setGlobalSize={setSize}
          />

        </div>
        <Keyboard showLogin={setShowLogin} user={user} loggedin={loggedIn} board={board} insert_key={insert_key} delete_key={delete_key} submit_word={submit_word}
          wrongLetters={wrongLetters}
          correctLetters={correctLetters}
          missLetters={missLetters}
          currentWord={currentWord}
          size={size}
          loggedIn={loggedIn}
          setRegisterOpen={setShowRegister}
          setLoginOpen={setShowLogin}
        />

      </main>


      <SettingsModal open={showSettings} setIsOpen={setShowSettings} hardMode={hardMode} setHardMode={setHardMode} board={board} />



      <AnimatePresence>
        {error.length > 0 &&
          <motion.div initial={{ x: 'calc(-50% - 100px )', y: '-50%', opacity: 0 }} animate={{ x: '-50%', y: '-50%', opacity: 1 }} exit={{ x: 'calc(-50% + 100px )', y: '-50%', opacity: 0 }} transition={{ type: 'ease' }} className="p-4 bg-white dark:bg-gray-700 absolute border-l-[6px] border-red-500 top-1/2 left-1/2  shadow-lg dark:text-white  rounded-md text-lg font-medium">
            {error}
          </motion.div>}
      </AnimatePresence>

      <HowToPlay open={showTutorial} setIsOpen={setShowTutorial} />
      <UserStats open={showStats} setIsOpen={setShowStats} stats={stats} />
      <LoginModal open={showLogin} setIsOpen={setShowLogin} loggedIn={loggedIn} />
      <RegisterModal open={showRegister} setIsOpen={setShowRegister} loggedIn={loggedIn} />
    </div>
  )
}

export async function getServerSideProps(ctx) {

  const { cookies } = ctx.req;
  const loggedIn = cookies["wordle-user"] != undefined;
  const connection = knex(dbconfig);

  let q = [];
  if (loggedIn) q = await connection("users").where('username', 'like', cookies["wordle-user"]);

  let isAdmin = false;
  if (q.length > 0) isAdmin = q[0].is_admin == 1;


  const five_answers_q = await connection('five_answers').select('word')
  const five_guesses_q = await connection('five_words').select()

  const six_answers_q = await connection('six_answers').select()
  const six_guesses_q = await connection('six_words').select()

  const seven_answers_q = await connection('seven_answers').select()
  const seven_guesses_q = await connection('seven_words').select()

  const words = {
    five: {
      guesses: [],
      answers: []
    },
    six: {
      guesses: [],
      answers: []
    },
    seven: {
      guesses: [],
      answers: []
    },
  }

  five_answers_q.forEach(w => {
    words.five.answers.push(w["word"])
  })
  six_answers_q.forEach(w => {
    words.six.answers.push(w["word"])
  })
  seven_answers_q.forEach(w => {
    words.seven.answers.push(w["word"])
  })

  five_guesses_q.forEach(w => {
    words.five.guesses.push(w["word"])
  })
  six_guesses_q.forEach(w => {
    words.six.guesses.push(w["word"])
  })
  seven_guesses_q.forEach(w => {
    words.seven.guesses.push(w["word"])
  })

  connection.destroy()

  return {
    props: {
      words, loggedIn, isAdmin, user: loggedIn ? JSON.parse(JSON.stringify(q[0])) : null
    }
  }
}