import Link from "next/link";

export default function Login() {
  return (
    <main
      className="bg-gray-50 h-screen w-screen
     grid place-items-center"
    >
      <div className="bg-white p-4 rounded-md shadow-xl w-full max-w-xs text-center flex flex-col gap-4">
        <h1 className="text-xl font-medium my-2">Register</h1>
        <input
        required
        type="text"
          className="border rounded w-full p-2 bg-gray-200 placeholder:text-gray-500 placeholder:font-medium"
          placeholder="username"
        />
        <input
        required
          type="email"
          className="border rounded w-full p-2 bg-gray-200 placeholder:text-gray-500 placeholder:font-medium"
          placeholder="email"
        />
        <input
        required
        type="password"
          className="border rounded w-full p-2 bg-gray-200 placeholder:text-gray-500 placeholder:font-medium"
          placeholder="password"
        />
        <button className="w-full bg-emerald-600 py-2 rounded-md text-white font-medium hover:bg-emerald-700">
          Register
        </button>
        <Link href={'/login'} passHref>
          <a
            className="hover:bg-emerald-500/10 py-2 rounded-md text-gray-700 hover:text-emerald-800"
          >
            Login
          </a>
        </Link>
      </div>
    </main>
  );
}
