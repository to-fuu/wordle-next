import knex from "knex";
import Head from "next/head";
import { useRouter } from "next/router";
import { useState } from "react";
import DataTable from "react-data-table-component";
import { AiOutlineDelete } from "react-icons/ai";
import { dbconfig } from "../database/db_connection";

export default function Login({ status, users, words }) {
  const router = useRouter();

  const [newFiveGuess, setNewFiveGuess] = useState("");
  const [newSixGuess, setNewSixGuess] = useState("");
  const [newSevenGuess, setNewSevenGuess] = useState("");
  const [newFiveAnswer, setNewFiveAnswer] = useState("");
  const [newSevenAnswer, setNewSevenAnswer] = useState("");
  const [newSixAnswer, setNewSixAnswer] = useState("");

  const addword = async (word, length, type) => {
    let table = "";

    table = `${length == 5 ? "five" : length == 6 ? "six" : "seven"}_${
      type === "a" ? "answers" : "words"
    }`;
    console.log(table);
    const res = await fetch("/api/word", {
      method: "POST",
      body: JSON.stringify({
        word,
        table,
        action: "add",
      }),
    });
    console.log(await res.json());
    // router.reload();
  };

  const columns = [
    {
      name: "Username",
      selector: (row) => row.username,
    },
    {
      name: "Email",
      selector: (row) => row.email,
      grow: 1,
    },
    {
      name: "Created",
      selector: (row) => row.create_datetime,
    },
    {
      name: "games_played",
      selector: (row) => row.games_played,
    },
    {
      name: "games_won",
      selector: (row) => row.games_won,
    },
    {
      name: "current_winstreak",
      selector: (row) => row.current_winstreak,
    },
    {
      name: "biggest_winstreak",
      selector: (row) => row.biggest_winstreak,
    },
    {
      name: "enabled",
      selector: (row) => row.enabled,
    },
    {
      name: "is_admin",
      selector: (row) => row.is_admin,
    },
    {
      name: "",
      cell: (row) => (
        <button
          onClick={async () => {
            await fetch("/api/user", {
              method: "POST",
              body: JSON.stringify({
                username: row.username,
                action: row.is_admin == 1 ? "revokesu" : "makesu",
              }),
            });
            router.reload();
          }}
          className="flex gap-2 items-center bg-gray-600 text-white hover:opacity-95 px-2 py-1 rounded text-xs"
        >
          {row.is_admin == 1 ? "Revoke Admin" : "Set admin"}
        </button>
      ),
    },
    {
      name: "",
      grow: 0,
      cell: (row) => (
        <button
          onClick={async () => {
            await fetch("/api/user", {
              method: "POST",
              body: JSON.stringify({
                username: row.username,
                action: row.enabled ? "disable" : "enable",
              }),
            });
            router.reload();
          }}
          className="flex gap-2 items-center bg-gray-600 text-white hover:opacity-95 px-2 py-1 rounded text-xs"
        >
          {row.enabled == 1 ? "Disable" : "Enable"}
        </button>
      ),
    },
    {
      name: "",
      grow: 0,
      cell: (row) => (
        <button
          onClick={async () => {
            await fetch("/api/user", {
              method: "POST",
              body: JSON.stringify({
                username: row.username,
                action: "delete",
              }),
            });
            router.reload();
          }}
          className="flex gap-2 items-center bg-red-600 text-white hover:opacity-95 px-2 py-1 rounded text-xs"
        >
          Delete
        </button>
      ),
    },
  ];

  const fivewordColumns = [
    {
      name: "word",
      selector: (row) => row,
    },
    {
      name: "",
      grow: 0,
      cell: (row) => (
        <button
          onClick={async () => {
            await fetch("/api/word", {
              method: "POST",
              body: JSON.stringify({
                table: "five_words",
                word: row,
                action: "delete",
              }),
            });
            router.reload();
          }}
          className="flex gap-2 items-center bg-red-600 text-white hover:opacity-95 px-2 py-1 rounded text-xs"
        >
          Delete
        </button>
      ),
    },
  ];
  const sixwordColumns = [
    {
      name: "word",
      selector: (row) => row,
    },
    {
      name: "",
      grow: 0,
      cell: (row) => (
        <button
          onClick={async () => {
            await fetch("/api/word", {
              method: "POST",
              body: JSON.stringify({
                table: "six_words",
                word: row,
                action: "delete",
              }),
            });
            router.reload();
          }}
          className="flex gap-2 items-center bg-red-600 text-white hover:opacity-95 px-2 py-1 rounded text-xs"
        >
          Delete
        </button>
      ),
    },
  ];
  const sevenwordColumns = [
    {
      name: "word",
      selector: (row) => row,
    },
    {
      name: "",
      grow: 0,
      cell: (row) => (
        <button
          onClick={async () => {
            await fetch("/api/word", {
              method: "POST",
              body: JSON.stringify({
                table: "seven_words",
                word: row,
                action: "delete",
              }),
            });
            router.reload();
          }}
          className="flex gap-2 items-center bg-red-600 text-white hover:opacity-95 px-2 py-1 rounded text-xs"
        >
          Delete
        </button>
      ),
    },
  ];
  const fiveanswerColumns = [
    {
      name: "word",
      selector: (row) => row,
    },
    {
      name: "",
      grow: 0,
      cell: (row) => (
        <button
          onClick={async () => {
            await fetch("/api/word", {
              method: "POST",
              body: JSON.stringify({
                table: "five_answers",
                word: row,
                action: "delete",
              }),
            });
            router.reload();
          }}
          className="flex gap-2 items-center bg-red-600 text-white hover:opacity-95 px-2 py-1 rounded text-xs"
        >
          Delete
        </button>
      ),
    },
  ];
  const sixanswerColumns = [
    {
      name: "word",
      selector: (row) => row,
    },
    {
      name: "",
      grow: 0,
      cell: (row) => (
        <button
          onClick={async () => {
            await fetch("/api/word", {
              method: "POST",
              body: JSON.stringify({
                table: "six_answers",
                word: row,
                action: "delete",
              }),
            });
            router.reload();
          }}
          className="flex gap-2 items-center bg-red-600 text-white hover:opacity-95 px-2 py-1 rounded text-xs"
        >
          Delete
        </button>
      ),
    },
  ];
  const sevenanswerColumns = [
    {
      name: "word",
      selector: (row) => row,
    },
    {
      name: "",
      grow: 0,
      cell: (row) => (
        <button
          onClick={async () => {
            await fetch("/api/word", {
              method: "POST",
              body: JSON.stringify({
                table: "seven_answers",
                word: row,
                action: "delete",
              }),
            });
            router.reload();
          }}
          className="flex gap-2 items-center bg-red-600 text-white hover:opacity-95 px-2 py-1 rounded text-xs"
        >
          Delete
        </button>
      ),
    },
  ];
  return status == 400 ? (
    <>
      <Head>
        <title>404: This page could not be found</title>
        <meta name="description" content="404: This page could not be found" />
      </Head>
      <main
        className="bg-gray-50 h-screen w-screen
     grid place-items-center"
      >
        <div className="flex items-center">
          <span className="text-2xl  border-r border-[rgba(0,0,0,0.3)] p-[10px_23px_10px_0] mr-5">
            404
          </span>
          <span className="text-sm">This page could not be found.</span>{" "}
        </div>
      </main>
    </>
  ) : (
    <main
      className="bg-gray-50 min-h-screen overflow-x-clip py-20 flex flex-col items-center
   "
    >
      <div className="max-w-screen-2xl w-full mb-4">
        <h1 className="text-xl font-bold">Users</h1>
      </div>
      <div className="shadow rounded-lg w-full max-w-screen-2xl">
        <DataTable
          highlightOnHover
          dense
          columns={columns}
          data={users}
          pagination
        ></DataTable>
      </div>

      <div className="max-w-screen-2xl w-full my-4 flex gap-2 items-center ">
        <h1 className="text-xl font-bold">Five letter guesses</h1>
        <input
          type="text"
          value={newFiveGuess}
          onChange={(e) => {
            setNewFiveGuess(e.target.value);
          }}
          placeholder="event"
          className="py-1 px-2 border border-gray-400 rounded ml-auto"
        />
        <button
          onClick={() => {
            addword(newFiveGuess, 5, "g");
          }}
          className="flex gap-2 items-center bg-gray-600 text-white hover:opacity-95 px-2 py-2 rounded text-xs"
        >
          Add
        </button>
      </div>

      <div className="shadow rounded-lg w-full max-w-screen-2xl ">
        <DataTable
          highlightOnHover
          dense
          columns={fivewordColumns}
          data={words.five.guesses}
          pagination
        ></DataTable>
      </div>

      <div className="max-w-screen-2xl w-full my-4 flex gap-2 items-center ">
        <h1 className="text-xl font-bold">Five letter Answers</h1>
        <input
          value={newFiveAnswer}
          onChange={(e) => {
            setNewFiveAnswer(e.target.value);
          }}
          type="text"
          placeholder="event"
          className="py-1 px-2 border border-gray-400 rounded ml-auto"
        />
        <button
          onClick={() => {
            addword(newFiveAnswer, 5, "a");
          }}
          className="flex gap-2 items-center bg-gray-600 text-white hover:opacity-95 px-2 py-2 rounded text-xs"
        >
          Add
        </button>
      </div>

      <div className="shadow rounded-lg w-full max-w-screen-2xl ">
        <DataTable
          highlightOnHover
          dense
          columns={fiveanswerColumns}
          data={words.five.answers}
          pagination
        ></DataTable>
      </div>

      <div className="max-w-screen-2xl w-full my-4 flex gap-2 items-center ">
        <h1 className="text-xl font-bold">Six letter guesses</h1>
        <input
          value={newSixGuess}
          onChange={(e) => {
            setNewSixGuess(e.target.value);
          }}
          type="text"
          placeholder="event"
          className="py-1 px-2 border border-gray-400 rounded ml-auto"
        />{" "}
        <button
          onClick={() => {
            addword(newSixGuess, 6, "g");
          }}
          className="flex gap-2 items-center bg-gray-600 text-white hover:opacity-95 px-2 py-2 rounded text-xs"
        >
          Add
        </button>
      </div>

      <div className="shadow rounded-lg w-full max-w-screen-2xl ">
        <DataTable
          highlightOnHover
          dense
          columns={sixwordColumns}
          data={words.six.guesses}
          pagination
        ></DataTable>
      </div>

      <div className="max-w-screen-2xl w-full my-4 flex gap-2 items-center ">
        <h1 className="text-xl font-bold">Six letter answers</h1>
        <input
          value={newSixAnswer}
          onChange={(e) => {
            setNewSixAnswer(e.target.value);
          }}
          type="text"
          placeholder="event"
          className="py-1 px-2 border border-gray-400 rounded ml-auto"
        />{" "}
        <button
          onClick={() => {
            addword(newSixAnswer, 6, "a");
          }}
          className="flex gap-2 items-center bg-gray-600 text-white hover:opacity-95 px-2 py-2 rounded text-xs"
        >
          Add
        </button>
      </div>

      <div className="shadow rounded-lg w-full max-w-screen-2xl ">
        <DataTable
          highlightOnHover
          dense
          columns={sixanswerColumns}
          data={words.six.answers}
          pagination
        ></DataTable>
      </div>

      <div className="max-w-screen-2xl w-full my-4 flex gap-2 items-center ">
        <h1 className="text-xl font-bold">Seven letter guesses</h1>
        <input
          value={newSevenGuess}
          onChange={(e) => {
            setNewSevenGuess(e.target.value);
          }}
          type="text"
          placeholder="event"
          className="py-1 px-2 border border-gray-400 rounded ml-auto"
        />{" "}
        <button
          onClick={() => {
            addword(newSevenGuess, 7, "g");
          }}
          className="flex gap-2 items-center bg-gray-600 text-white hover:opacity-95 px-2 py-2 rounded text-xs"
        >
          Add
        </button>
      </div>

      <div className="shadow rounded-lg w-full max-w-screen-2xl ">
        <DataTable
          highlightOnHover
          dense
          columns={sevenwordColumns}
          data={words.seven.guesses}
          pagination
        ></DataTable>
      </div>

      <div className="max-w-screen-2xl w-full my-4 flex gap-2 items-center ">
        <h1 className="text-xl font-bold">Seven letter answers</h1>
        <input
          value={newSevenAnswer}
          onChange={(e) => {
            setNewSevenAnswer(e.target.value);
          }}
          type="text"
          placeholder="event"
          className="py-1 px-2 border border-gray-400 rounded ml-auto"
        />{" "}
        <button
          onClick={() => {
            addword(newSevenAnswer, 7, "a");
          }}
          className="flex gap-2 items-center bg-gray-600 text-white hover:opacity-95 px-2 py-2 rounded text-xs"
        >
          Add
        </button>
      </div>
      <div className="shadow rounded-lg w-full max-w-screen-2xl ">
        <DataTable
          highlightOnHover
          dense
          columns={sevenanswerColumns}
          data={words.seven.answers}
          pagination
        ></DataTable>
      </div>
    </main>
  );
}

export async function getServerSideProps(ctx) {
  const { cookies } = ctx.req;
  const user = cookies["wordle-user"];

  const connection = knex(dbconfig);
  const q = await connection("users");
  const admin = q.some((_q) => _q["username"] == user && _q["is_admin"] == 1);
  const users = JSON.parse(JSON.stringify(q));

  const five_answers_q = await connection("five_answers").select("word");
  const five_guesses_q = await connection("five_words").select();

  const six_answers_q = await connection("six_answers").select();
  const six_guesses_q = await connection("six_words").select();

  const seven_answers_q = await connection("seven_answers").select();
  const seven_guesses_q = await connection("seven_words").select();

  const words = {
    five: {
      guesses: [],
      answers: [],
    },
    six: {
      guesses: [],
      answers: [],
    },
    seven: {
      guesses: [],
      answers: [],
    },
  };

  five_answers_q.forEach((w) => {
    words.five.answers.push(w["word"]);
  });
  six_answers_q.forEach((w) => {
    words.six.answers.push(w["word"]);
  });
  seven_answers_q.forEach((w) => {
    words.seven.answers.push(w["word"]);
  });

  five_guesses_q.forEach((w) => {
    words.five.guesses.push(w["word"]);
  });
  six_guesses_q.forEach((w) => {
    words.six.guesses.push(w["word"]);
  });
  seven_guesses_q.forEach((w) => {
    words.seven.guesses.push(w["word"]);
  });

  connection.destroy();

  if (admin) {
    return {
      props: {
        status: 200,
        users,
        words,
      },
    };
  } else {
    return {
      props: {
        status: 400,
      },
    };
  }
}
