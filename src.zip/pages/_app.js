import Head from 'next/head'
import { useEffect } from 'react'
import '../styles/globals.css'
import { hotjar } from 'react-hotjar'
import smartlookClient from 'smartlook-client'
import TagManager from 'react-gtm-module'

function MyApp({ Component, pageProps }) {
  useEffect(() => {
    hotjar.initialize(2811686, 6)
    smartlookClient.init('e05f55c75e7d25ceeaca836a0365cc045918809b')

    const tagManagerArgs = {
      gtmId: 'G-XZW2JRT705'
    };

    TagManager.initialize(tagManagerArgs)

  }, [])
  return <>
    <Head>
      <link rel="icon" href="/ico.svg" />
    </Head>
    <Component {...pageProps} />
  </>
}

export default MyApp
