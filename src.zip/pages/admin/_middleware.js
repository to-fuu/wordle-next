import { NextRequest, NextResponse } from 'next/server'

export async function middleware(req, ev) {
    if (req.nextUrl.pathname.startsWith("/admin") && !req.cookies["wordle-user"]) {
        return NextResponse.redirect('/')
    }



    return NextResponse.next()
}