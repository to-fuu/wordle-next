// Next.js API route support: https://nextjs.org/docs/api-routes/introduction

import knex from "knex";
import { dbconfig } from "../../database/db_connection";

export default async function handler(req, res) {
  const connection = knex(dbconfig);

  if (req.method === 'POST') {
    const { username, action } = JSON.parse(req.body)

    try {
      switch (action) {
        case 'disable':
          await connection('users').where('username', 'like', username).update({ enabled: false })
          break;
        case 'enable':
          await connection('users').where('username', 'like', username).update({ enabled: true })
          break;
        case 'makesu':
          await connection('users').where('username', 'like', username).update({ is_admin: 1 })
          break;
        case 'revokesu':
          await connection('users').where('username', 'like', username).update({ is_admin: 0 })
          break;
        case 'delete':
          await connection('users').where('username', 'like', username).delete()
          break;
        case 'pay':
          await connection('users').where('username', 'like', username).update({ paid: 1 })
          break;
      }
      connection.destroy()
      return res.status(200).json({})

    } catch (e) {
      connection.destroy()
      return res.status(400).json({})
    }
  }

}
