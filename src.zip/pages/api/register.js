import knex from "knex";
import { dbconfig } from "../../database/db_connection";
import md5 from "md5";
export default async function handler(req, res) {
  const connection = knex(dbconfig);
  const action = req.cookies["wordle-action"]

  if (req.method === 'POST') {
    const { username, password, email } = JSON.parse(req.body)
    const q = await connection('users').where('username', 'like', username).orWhere('email', 'like', email)

    if (q.length > 0) {
      connection.destroy()
      return res.status(400).json({
        error: 'Email or Username already exists'
      })
    } else {

      const hashedPass = md5(password)
      let paid = 0;
      if (action === "unlm") {
        paid = 1
      }
      await connection('users').insert({ username, password: hashedPass, email, create_datetime: new Date(), paid })
      return res.status(200).json({})

    }


    return res.status(400).json({
      error: 'Please Try Again'
    })

  }
}
