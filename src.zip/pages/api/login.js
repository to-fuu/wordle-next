import knex from "knex";
import { dbconfig } from "../../database/db_connection";
import md5 from "md5";
export default async function handler(req, res) {
  const connection = knex(dbconfig);

  if (req.method === 'POST') {
    const { username, password } = JSON.parse(req.body)
    const hashedPass = md5(password)
    const q = await connection('users').where('username', 'like', username).andWhere('password', 'like', hashedPass).select('username', 'is_admin','enabled').first()
    connection.destroy()
    if (q) {
      if (q["enabled"] === 0) {
        return res.status(400).json({
          error: 'Your account has been disabled.'
        })
      }
      return res.status(200).json({
        ...q
      })
    } else {
      return res.status(400).json({
        error: 'Invalid credentials'
      })
    }


  }
}
