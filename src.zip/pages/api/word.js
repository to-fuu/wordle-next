// Next.js API route support: https://nextjs.org/docs/api-routes/introduction

import knex from "knex";
import { dbconfig } from "../../database/db_connection";
import md5 from "md5";
export default async function handler(req, res) {
  const connection = knex(dbconfig);

  if (req.method === 'POST') {
    const { table, action, word } = JSON.parse(req.body)

    try {
      switch (action) {
        case 'delete':
          await connection(table).where('word', 'like', word).delete()
          break;
        case 'add':
          const q = await connection(table).where('word', 'like', word).insert({ word })
          console.log(q);
          break;
      }
      connection.destroy()
      return res.status(200).json({ m: 'added' })

    } catch (e) {
      connection.destroy()
      return res.status(400).json({})
    }





  }
}
