import knex from "knex";
import { dbconfig } from "../../database/db_connection";

export default async function handler(req, res) {
  const user = req.cookies["wordle-user"]
  const connection = knex(dbconfig);

  if (req.method === "GET") {
    const q = await connection('users').select().where('username', 'like', user)
    connection.destroy()
    return res.status(200).json({
      games: q[0]['games_played'],
      won: q[0]['games_won'],
      streak: q[0]['current_winstreak'],
      hscore: q[0]['biggest_winstreak'],
    })
  } else if (req.method === 'POST') {
    const { games, won, streak, hscore } = JSON.parse(req.body)
    const q = await connection('users').where('username', 'like', user).update({
      games_played: games,
      games_won: won,
      current_winstreak: streak,
      biggest_winstreak: hscore,
    })
    connection.destroy()
    return res.status(200).json({
      games, won, streak, hscore
    })

  }
}
